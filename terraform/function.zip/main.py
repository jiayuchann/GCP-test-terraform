from google.cloud import bigquery, monitoring_v3
import time

def bigquery_to_metric(request):
    client_bq = bigquery.Client()

    query = """
        SELECT name, gender, count
        FROM `bigquery-stuff-389701.babynames.names_2014`
        WHERE gender = 'F'
        ORDER BY name ASC
        LIMIT 10
        OFFSET 5000
    """
    query_job = client_bq.query(query)
    results = query_job.result()  # Waits for job to complete.

    for row in results:
        name = row[0]
        count = row[2]

        # create a client for Monitoring
        client = monitoring_v3.MetricServiceClient()
        project_name = f"projects/bigquery-stuff-389701"

        series = monitoring_v3.TimeSeries()
        series.metric.type = f'custom.googleapis.com/test_metric'
        series.metric.labels['name'] = name
        series.resource.type = 'global'

        now = time.time()
        seconds = int(now)
        nanos = int((now - seconds) * 10**9)
        interval = monitoring_v3.TimeInterval(
            {"end_time": {"seconds": seconds, "nanos": nanos}}
        )

        point = monitoring_v3.Point({"interval": interval, "value": {"int64_value": count}})
        series.points = [point]
        client.create_time_series(name=project_name, time_series=[series])

    return f'Wrote data to custom metric'
